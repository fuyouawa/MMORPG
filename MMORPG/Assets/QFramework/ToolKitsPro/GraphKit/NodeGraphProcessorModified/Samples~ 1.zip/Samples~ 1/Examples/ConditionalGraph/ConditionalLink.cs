namespace NodeGraphProcessor.Examples
{
    public struct ConditionalLink {}
}
