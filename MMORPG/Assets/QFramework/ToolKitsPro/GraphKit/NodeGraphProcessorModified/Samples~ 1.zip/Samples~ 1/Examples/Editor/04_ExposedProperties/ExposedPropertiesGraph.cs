#if UNITY_2019_4_OR_NEWER
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using GraphProcessor;

public class ExposedPropertiesGraph : BaseGraph
{

}
#endif